from django.apps import AppConfig


class BlurbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blurb'
